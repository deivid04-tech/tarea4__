const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const db = new sqlite3.Database('./database.sqlite');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
  secret: 'secret_key_for_demo',
  resave: false,
  saveUninitialized: true
}));

// Simple hardcoded user (username: admin, password: admin123)
const AUTH_USER = { username: 'admin', password: 'admin123' };

function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.redirect('/login');
}

// Routes
app.get('/', (req, res) => {
  if (req.session && req.session.user) return res.redirect('/contacts');
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === AUTH_USER.username && password === AUTH_USER.password) {
    req.session.user = { username };
    return res.redirect('/contacts');
  }
  res.render('login', { error: 'Credenciales inválidas' });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// Contacts - CRUD
app.get('/contacts', requireAuth, (req, res) => {
  db.all("SELECT * FROM contacts ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).send("Error DB");
    res.render('contacts/index', { contacts: rows, user: req.session.user });
  });
});

app.get('/contacts/new', requireAuth, (req, res) => {
  res.render('contacts/new', { user: req.session.user, error: null, contact: {} });
});

app.post('/contacts', requireAuth, (req, res) => {
  const { name, email, phone } = req.body;
  if (!name || !email) {
    return res.render('contacts/new', { user: req.session.user, error: 'Name y email son obligatorios', contact: req.body });
  }
  db.run("INSERT INTO contacts (name,email,phone) VALUES (?,?,?)", [name,email,phone], function(err){
    if (err) return res.status(500).send("Error DB insert");
    res.redirect('/contacts');
  });
});

app.get('/contacts/:id/edit', requireAuth, (req, res) => {
  const id = req.params.id;
  db.get("SELECT * FROM contacts WHERE id = ?", [id], (err, row) => {
    if (err || !row) return res.redirect('/contacts');
    res.render('contacts/edit', { contact: row, user: req.session.user, error: null });
  });
});

app.post('/contacts/:id', requireAuth, (req, res) => {
  const id = req.params.id;
  const { name, email, phone } = req.body;
  if (!name || !email) {
    db.get("SELECT * FROM contacts WHERE id = ?", [id], (err, row) => {
      return res.render('contacts/edit', { contact: row, user: req.session.user, error: 'Name y email son obligatorios' });
    });
  } else {
    db.run("UPDATE contacts SET name=?, email=?, phone=? WHERE id=?", [name,email,phone,id], function(err){
      if (err) return res.status(500).send("Error DB update");
      res.redirect('/contacts');
    });
  }
});

app.post('/contacts/:id/delete', requireAuth, (req, res) => {
  const id = req.params.id;
  db.run("DELETE FROM contacts WHERE id = ?", [id], function(err){
    if (err) return res.status(500).send("Error DB delete");
    res.redirect('/contacts');
  });
});

// Simple health
app.get('/health', (req, res) => res.send('OK'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`App listening on http://localhost:${PORT}`));
