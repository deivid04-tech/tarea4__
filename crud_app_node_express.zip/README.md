# CRUD App - Node.js + Express + SQLite

## Qué incluye
- Login simple (usuario: `admin`, contraseña: `admin123`)
- CRUD de Contacts (name, email, phone)
- EJS templates
- Script para inicializar la base de datos

## Ejecutar localmente
1. Instala dependencias:
   ```bash
   npm install
   ```
2. Inicializa la base de datos:
   ```bash
   npm run init-db
   ```
3. Ejecuta la app:
   ```bash
   npm start
   ```
4. Abre en el navegador: `http://localhost:3000`

## Notas
- Está listo para subir a GitHub directamente.
- Para usar con pruebas Selenium asegúrate de que la app esté corriendo y accesible.
