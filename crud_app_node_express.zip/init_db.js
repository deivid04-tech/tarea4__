const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.sqlite');

db.serialize(function() {
  db.run("CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT)");
  // Optional: insert sample data
  db.run("INSERT INTO contacts (name,email,phone) VALUES (?,?,?)", ['Juan Pérez','juan@example.com','809-000-0000']);
  db.run("INSERT INTO contacts (name,email,phone) VALUES (?,?,?)", ['María Gómez','maria@example.com','809-111-1111']);
});

db.close();
console.log('Database initialized.');
